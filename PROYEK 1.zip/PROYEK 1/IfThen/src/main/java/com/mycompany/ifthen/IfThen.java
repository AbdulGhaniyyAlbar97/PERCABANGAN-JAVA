/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ifthen;

/**
 *
 * @author admin
 */
public class IfThen {

    public static void main(String[] args) {
        System.out.println("coba IfThen");
        boolean isOn = true;
        
        if (isOn) 
            System.out.println("Menyalakan Lampu");
        }
    }
